import React from 'react';
import { Square, Folders, Save, FolderOpen } from 'lucide-react';
import { DraggableToolbarItem } from './DraggableToolbarItem';

interface ToolbarProps {
  onAddBlock: (x: number, y: number) => void;
  onAddGroup: (x: number, y: number) => void;
  onSave: () => void;
  onOpen: () => void;
}

export function Toolbar({ onAddBlock, onAddGroup, onSave, onOpen }: ToolbarProps) {
  return (
    <div className="p-4 flex flex-col gap-4">
      <DraggableToolbarItem onDrop={onAddBlock} title="Add Block">
        <Square className="w-6 h-6" />
      </DraggableToolbarItem>
      
      <DraggableToolbarItem onDrop={onAddGroup} title="Add Group">
        <Folders className="w-6 h-6" />
      </DraggableToolbarItem>

      <div className="w-full h-px bg-gray-200 my-2" />
      
      <button
        onClick={onSave}
        className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        title="Save Diagram"
      >
        <Save className="w-6 h-6" />
      </button>
      
      <button
        onClick={onOpen}
        className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        title="Open Diagram"
      >
        <FolderOpen className="w-6 h-6" />
      </button>
    </div>
  );
}