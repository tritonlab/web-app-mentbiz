import React, { useRef } from 'react';
import Draggable from 'react-draggable';
import { Block } from '../types';

interface DiagramBlockProps {
  block: Block;
  selected: boolean;
  onSelect: () => void;
  onPositionChange: (x: number, y: number) => void;
  onStartConnection: (blockId: string, point: { x: number; y: number }) => void;
  onEndConnection: (blockId: string) => void;
}

export function DiagramBlock({
  block,
  selected,
  onSelect,
  onPositionChange,
  onStartConnection,
  onEndConnection,
}: DiagramBlockProps) {
  const nodeRef = useRef(null);
  const blockWidth = 100;
  const blockHeight = 80;

  const handleMouseDown = (e: React.MouseEvent, position: string) => {
    if (e.button === 0) { // Left click only
      const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
      const workArea = document.getElementById('work-area')?.getBoundingClientRect();
      
      if (workArea) {
        const point = {
          x: rect.left - workArea.left + (position === 'right' ? blockWidth : 0),
          y: rect.top - workArea.top + blockHeight / 2,
        };
        onStartConnection(block.id, point);
      }
    }
  };

  return (
    <Draggable
      nodeRef={nodeRef}
      position={{ x: block.x, y: block.y }}
      onDrag={(e, data) => onPositionChange(data.x, data.y)}
      bounds="parent"
      grid={[10, 10]}
    >
      <div
        ref={nodeRef}
        className={`absolute cursor-move select-none ${
          selected ? 'ring-2 ring-blue-500' : ''
        }`}
        onClick={(e) => {
          e.stopPropagation();
          onSelect();
        }}
        style={{
          width: `${blockWidth}px`,
          height: `${blockHeight}px`,
          backgroundColor: block.color,
          border: `${block.borderWidth}px solid ${block.borderColor}`,
          borderRadius: '12px',
        }}
      >
        <div className="w-full h-full flex items-center justify-center p-2 text-center break-words">
          {block.name}
        </div>
        
        {/* Connection points */}
        <div
          className="absolute left-0 top-1/2 w-3 h-3 bg-gray-400 rounded-full transform -translate-x-1/2 -translate-y-1/2 hover:bg-blue-500 cursor-crosshair"
          onMouseDown={(e) => handleMouseDown(e, 'left')}
          onMouseUp={() => onEndConnection(block.id)}
        />
        <div
          className="absolute right-0 top-1/2 w-3 h-3 bg-gray-400 rounded-full transform translate-x-1/2 -translate-y-1/2 hover:bg-blue-500 cursor-crosshair"
          onMouseDown={(e) => handleMouseDown(e, 'right')}
          onMouseUp={() => onEndConnection(block.id)}
        />
      </div>
    </Draggable>
  );
}