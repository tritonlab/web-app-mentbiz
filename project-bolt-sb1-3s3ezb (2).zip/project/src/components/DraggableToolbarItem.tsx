import React from 'react';

interface DraggableToolbarItemProps {
  children: React.ReactNode;
  title: string;
  onDrop: (x: number, y: number) => void;
}

export function DraggableToolbarItem({ children, title, onDrop }: DraggableToolbarItemProps) {
  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('text/plain', title);
    e.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="p-2 hover:bg-gray-100 rounded-lg transition-colors cursor-grab active:cursor-grabbing"
      title={title}
    >
      {children}
    </div>
  );
}