import React from 'react';
import { Connection as ConnectionType, Point } from '../types';

interface ConnectionProps {
  connection: ConnectionType;
  selected: boolean;
  onClick: () => void;
}

export function Connection({ connection, selected, onClick }: ConnectionProps) {
  const generatePath = (points: Point[]) => {
    if (points.length < 2) return '';
    
    const path = [`M ${points[0].x} ${points[0].y}`];
    
    for (let i = 1; i < points.length; i++) {
      path.push(`L ${points[i].x} ${points[i].y}`);
    }
    
    return path.join(' ');
  };

  return (
    <path
      d={generatePath(connection.points)}
      stroke={selected ? '#3b82f6' : '#9ca3af'}
      strokeWidth={selected ? 2 : 1.5}
      fill="none"
      className="cursor-pointer"
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
    />
  );
}