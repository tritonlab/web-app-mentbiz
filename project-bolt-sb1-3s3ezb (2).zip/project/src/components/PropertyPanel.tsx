import React from 'react';
import { Block } from '../types';

interface PropertyPanelProps {
  selectedBlock: Block | null;
  onUpdateBlock: (block: Block) => void;
}

export function PropertyPanel({ selectedBlock, onUpdateBlock }: PropertyPanelProps) {
  if (!selectedBlock) {
    return null;
  }

  const handleChange = (field: keyof Block, value: string | number) => {
    onUpdateBlock({ ...selectedBlock, [field]: value });
  };

  return (
    <div className="h-full p-6 overflow-y-auto">
      <h3 className="text-lg font-semibold mb-4">Block Properties</h3>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Name</label>
          <input
            type="text"
            value={selectedBlock.name}
            onChange={(e) => handleChange('name', e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Color</label>
          <input
            type="color"
            value={selectedBlock.color}
            onChange={(e) => handleChange('color', e.target.value)}
            className="mt-1 block w-full h-10 rounded-md"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Border Color</label>
          <input
            type="color"
            value={selectedBlock.borderColor}
            onChange={(e) => handleChange('borderColor', e.target.value)}
            className="mt-1 block w-full h-10 rounded-md"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Border Width</label>
          <input
            type="number"
            min="1"
            max="10"
            value={selectedBlock.borderWidth}
            onChange={(e) => handleChange('borderWidth', parseInt(e.target.value))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Algorithm</label>
          <textarea
            value={selectedBlock.algorithm || ''}
            onChange={(e) => handleChange('algorithm', e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 h-32"
            placeholder="Enter JavaScript code..."
          />
        </div>
      </div>
    </div>
  );
}