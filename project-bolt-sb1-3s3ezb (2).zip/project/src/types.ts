export interface Block {
  id: string;
  type: 'block' | 'group';
  x: number;
  y: number;
  name: string;
  color: string;
  borderColor: string;
  borderWidth: number;
  algorithm?: string;
  data?: any;
}

export interface Point {
  x: number;
  y: number;
}

export interface Connection {
  id: string;
  sourceId: string;
  targetId: string;
  points: Point[];
  data?: any;
}

export interface DiagramState {
  blocks: Block[];
  connections: Connection[];
}