import React, { useState, useCallback, useRef } from 'react';
import { Toolbar } from './components/Toolbar';
import { PropertyPanel } from './components/PropertyPanel';
import { DiagramBlock } from './components/DiagramBlock';
import { Connection } from './components/Connection';
import { Block, Connection as ConnectionType, Point, DiagramState } from './types';

function App() {
  const [diagram, setDiagram] = useState<DiagramState>({
    blocks: [],
    connections: [],
  });
  const [selectedBlock, setSelectedBlock] = useState<Block | null>(null);
  const [selectedConnection, setSelectedConnection] = useState<ConnectionType | null>(null);
  const [connectingFrom, setConnectingFrom] = useState<{ blockId: string; point: Point } | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const handleAddBlock = useCallback((x: number, y: number) => {
    const newBlock: Block = {
      id: `block-${Date.now()}`,
      type: 'block',
      x,
      y,
      name: 'New Block',
      color: '#ffffff',
      borderColor: '#000000',
      borderWidth: 2,
    };
    setDiagram((prev) => ({
      ...prev,
      blocks: [...prev.blocks, newBlock],
    }));
  }, []);

  const handleAddGroup = useCallback((x: number, y: number) => {
    const newBlock: Block = {
      id: `group-${Date.now()}`,
      type: 'group',
      x,
      y,
      name: 'New Group',
      color: '#f3f4f6',
      borderColor: '#9ca3af',
      borderWidth: 2,
    };
    setDiagram((prev) => ({
      ...prev,
      blocks: [...prev.blocks, newBlock],
    }));
  }, []);

  const handleSave = useCallback(() => {
    const data = JSON.stringify(diagram);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'flowchart.json';
    a.click();
    URL.revokeObjectURL(url);
  }, [diagram]);

  const handleOpen = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const data = JSON.parse(e.target?.result as string);
            setDiagram(data);
          } catch (error) {
            console.error('Error parsing file:', error);
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  }, []);

  const handleUpdateBlock = useCallback((updatedBlock: Block) => {
    setDiagram((prev) => ({
      ...prev,
      blocks: prev.blocks.map((block) =>
        block.id === updatedBlock.id ? updatedBlock : block
      ),
    }));
    setSelectedBlock(updatedBlock);
  }, []);

  const handleBlockPosition = useCallback((blockId: string, x: number, y: number) => {
    setDiagram((prev) => ({
      ...prev,
      blocks: prev.blocks.map((block) =>
        block.id === blockId ? { ...block, x, y } : block
      ),
      connections: prev.connections.map((conn) => {
        if (conn.sourceId === blockId || conn.targetId === blockId) {
          const points = [...conn.points];
          if (conn.sourceId === blockId) {
            points[0] = { x: x + 100, y: y + 40 };
          }
          if (conn.targetId === blockId) {
            points[points.length - 1] = { x, y: y + 40 };
          }
          return { ...conn, points };
        }
        return conn;
      }),
    }));
  }, []);

  const handleStartConnection = useCallback((blockId: string, point: Point) => {
    setConnectingFrom({ blockId, point });
  }, []);

  const handleEndConnection = useCallback((targetId: string) => {
    if (connectingFrom && connectingFrom.blockId !== targetId) {
      const sourceBlock = diagram.blocks.find((b) => b.id === connectingFrom.blockId);
      const targetBlock = diagram.blocks.find((b) => b.id === targetId);

      if (sourceBlock && targetBlock) {
        const points: Point[] = [
          connectingFrom.point,
          { x: (connectingFrom.point.x + targetBlock.x) / 2, y: connectingFrom.point.y },
          { x: (connectingFrom.point.x + targetBlock.x) / 2, y: targetBlock.y + 40 },
          { x: targetBlock.x, y: targetBlock.y + 40 },
        ];

        const newConnection: ConnectionType = {
          id: `conn-${Date.now()}`,
          sourceId: connectingFrom.blockId,
          targetId,
          points,
        };

        setDiagram((prev) => ({
          ...prev,
          connections: [...prev.connections, newConnection],
        }));
      }
    }
    setConnectingFrom(null);
  }, [connectingFrom, diagram.blocks]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const workArea = document.getElementById('work-area');
    if (workArea) {
      const rect = workArea.getBoundingClientRect();
      const x = e.clientX - rect.left - 50;
      const y = e.clientY - rect.top - 40;
      const type = e.dataTransfer.getData('text/plain');
      
      if (type === 'Add Block') {
        handleAddBlock(x, y);
      } else if (type === 'Add Group') {
        handleAddGroup(x, y);
      }
    }
  };

  return (
    <div className="h-screen bg-gray-50 overflow-hidden relative">
      {/* Work Area */}
      <div
        id="work-area"
        className="h-full w-full overflow-auto"
        onClick={() => {
          setSelectedBlock(null);
          setSelectedConnection(null);
        }}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <div className="absolute inset-0 min-w-full min-h-full">
          <svg
            ref={svgRef}
            className="absolute inset-0 w-full h-full pointer-events-none"
          >
            <g className="pointer-events-auto">
              {diagram.connections.map((connection) => (
                <Connection
                  key={connection.id}
                  connection={connection}
                  selected={selectedConnection?.id === connection.id}
                  onClick={() => setSelectedConnection(connection)}
                />
              ))}
            </g>
          </svg>
          {diagram.blocks.map((block) => (
            <DiagramBlock
              key={block.id}
              block={block}
              selected={selectedBlock?.id === block.id}
              onSelect={() => setSelectedBlock(block)}
              onPositionChange={(x, y) => handleBlockPosition(block.id, x, y)}
              onStartConnection={handleStartConnection}
              onEndConnection={handleEndConnection}
            />
          ))}
        </div>
      </div>

      {/* Left Toolbar - Floating */}
      <div className="absolute left-4 top-4 bg-white rounded-lg shadow-lg">
        <Toolbar
          onAddBlock={handleAddBlock}
          onAddGroup={handleAddGroup}
          onSave={handleSave}
          onOpen={handleOpen}
        />
      </div>

      {/* Right Property Panel - Floating */}
      {selectedBlock && (
        <div className="absolute right-4 top-4 bottom-4 w-80 bg-white rounded-lg shadow-lg">
          <PropertyPanel
            selectedBlock={selectedBlock}
            onUpdateBlock={handleUpdateBlock}
          />
        </div>
      )}
    </div>
  );
}

export default App;